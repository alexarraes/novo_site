# Change Log

## [1.1.0] 2017-08-30
### Bootstrap 4 Beta
- Changed the library Tether.js with Popper.js
- Renamed the old classes from Bootstrap 4 Alpha with the new Bootstrap 4 Beta classes
- Small bug fixes
- Added burger menu with sidebar menu for desktop/tablet (used to be only in mobile)
- Options for regular Bootstrap Collapse Navbar (using class `.bootstrap-collapse` on `<body>`) and Sidebar Collapse Navbar (using class `.sidebar-collapse` on `<body>`)

###

## [1.0.1] 2017-06-28
### Icons Update
- Changed source files for the icons, optimized from 2MB to 100KB

## [1.0.0] 2017-05-16
### Original Release
